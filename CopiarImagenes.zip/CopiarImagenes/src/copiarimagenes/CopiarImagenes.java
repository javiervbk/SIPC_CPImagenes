/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package copiarimagenes;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;

/**
 * 
 * 
 * Esta clase define objetos que contienen tantos enteros aleatorios entre 0 y 1000 como se le definen al crear un objeto
 * @author: Javier Villalobos
 * @version: 2.1
 * @see mis documentos
 *
 * Clase de prueba de conexión con una base de datos MySQL
 */
public class CopiarImagenes {
    
    /** 
     * Crea una instancia de la clase MySQL y realiza todo el código 
     * de conexión, consulta y muestra de resultados.
     * @throws java.sql.SQLException
     */
    public CopiarImagenes() throws ClassNotFoundException, SQLException 
    {
        // Se mete todo en un try por los posibles errores de MySQL
        try
        {
            // Se registra el Driver de MySQL
             Class.forName("com.mysql.jdbc.Driver");
            
            // Se obtiene una conexión con la base de datos. Hay que
            // cambiar el usuario "root" y la clave "la_clave" por las
            // adecuadas a la base de datos que estemos usando.
            Connection conexion = DriverManager.getConnection (
                "jdbc:mysql://localhost/consultas","root", "010101");
            
            // Se crea un Statement, para realizar la consulta
            Statement s = conexion.createStatement();
            
            // Se realiza la consulta. Los resultados se guardan en el 
            // ResultSet rs
            ResultSet rs = s.executeQuery ("select Archivo_de_imagen,NI,Numero_de_inventario, Pieza from fichas where Clave_de_museo=911 and Origen like '%CHINA%'");
            
            // Se recorre el ResultSet, mostrando por pantalla los resultados.
            int numeroentero = 0,numerovalido;
            double numerodouble;
            //Prueba de versiones
            String ruta="N/A";
           String sorigen;
           String sdestino;
           String anterior = null;
           String archivodeimagen;
           int contador=0;
            while (rs.next())
            {   
                if (rs.getString("Archivo_de_imagen")==null){
                    archivodeimagen=anterior;
                }else{
                    archivodeimagen=rs.getString("Archivo_de_imagen");
                }       
                System.out.println("ESTO DICE: "+archivodeimagen);
                if(rs.getString("Numero_de_inventario").contains("/")){
                    System.out.println("LOTE con numero de inventario: "+rs.getString("Numero_de_inventario"));
                    int numero;
                    numero=rs.getInt("Pieza");
                    if(0<numero){
                         System.out.println("MAS DE CERO");
                         System.out.println("Numero de imagen: "+rs.getInt("NI")+"_"+rs.getInt("Pieza"));
                         sorigen=archivodeimagen+rs.getInt("NI")+"_"+rs.getInt("Pieza")+".jpg";
                         sdestino="C:\\Users\\JAVIER VILLALOBOS\\Desktop\\imagenesdemuseo\\"+rs.getInt("NI")+"_"+rs.getInt("Pieza")+".jpg";
                    } else {
                         System.out.println("CERO");
                        System.out.println("Numero de imagen: "+rs.getInt("NI"));
                        sorigen=archivodeimagen+rs.getInt("NI")+".jpg";
                        sdestino="C:\\Users\\JAVIER VILLALOBOS\\Desktop\\imagenesdemuseo\\"+rs.getInt("NI")+".jpg";
                       
                    }
                    
                  
                    
                    
                } else {    
                    System.out.println("UNITARIO");
                    sorigen=archivodeimagen+rs.getInt("NI")+".jpg";
                    sdestino="C:\\Users\\JAVIER VILLALOBOS\\Desktop\\imagenesdemuseo\\"+rs.getInt("NI")+".jpg";
                 }
                
                
                
                File origen = new File(sorigen);
                File destino = new File(sdestino);

                try {
                        InputStream in = new FileInputStream(origen);
                        OutputStream out = new FileOutputStream(destino);
                                
                        byte[] buf = new byte[1024];
                        int len;

                        while ((len = in.read(buf)) > 0) {
                                out.write(buf, 0, len);
                        }
                
                        in.close();
                        out.close();
                } catch (IOException ioe){
                        ioe.printStackTrace();
                        contador++;
                }
                  
            
                anterior=rs.getString("Archivo_de_imagen");
                
              
            }
            System.out.println("SIN IMAGEN "+contador);
            conexion.close();
            // Se cierra la conexión con la base de datos.
           
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
    /**
     * Método principal, instancia una clase PruebaMySQL
     *
     * @param args the command line arguments
     * 
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException 
    {
        new CopiarImagenes();
    }
    
}